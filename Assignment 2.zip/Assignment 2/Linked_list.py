class Node:
    def __init__(self, value):
        self.data = value
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add_to_end(self, value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
            print(f"Added {value} as the first node.")
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
            print(f"Added {value} to the end of the list.")

    def print_list(self):
        if self.head is None:
            print("The list is currently empty.")
        else:
            current = self.head
            print("The linked list is:")
            while current:
                print(f"[{current.data}]", end=" -> ")
                current = current.next
            print("None")

    def delete_nth_node(self, position):
        try:
            if self.head is None:
                raise Exception("Cannot delete from an empty list.")

            if position <= 0:
                raise IndexError("Please enter a position greater than 0.")

            if position == 1:
                removed_value = self.head.data
                self.head = self.head.next
                print(f"Deleted node at position 1 with value {removed_value}")
                return

            current = self.head
            count = 1
            while current.next and count < position - 1:
                current = current.next
                count += 1

            if current.next is None:
                raise IndexError("Position out of range.")

            removed_value = current.next.data
            current.next = current.next.next
            print(f"Deleted node at position {position} with value {removed_value}")
        
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    my_list = LinkedList()
    my_list.add_to_end(10)
    my_list.add_to_end(20)
    my_list.add_to_end(30)
    my_list.add_to_end(40)
    my_list.add_to_end(50)

    my_list.print_list()

    my_list.delete_nth_node(3)
    my_list.print_list()

    my_list.delete_nth_node(1)
    my_list.print_list()

    my_list.delete_nth_node(10)

    empty_list = LinkedList()
    empty_list.delete_nth_node(1)
